分别为 depth=[0, 3] 的时候的处理结果(根目录为每个目录下的intern)  
若不选择要求3参照 no_depth  